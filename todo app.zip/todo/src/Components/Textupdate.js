import React, { useState } from "react";

const Text = (props) => {
  const [editMode, setEditMode] = useState(false)
  const [val, setVal] = useState(props.value)

  return (
    <div>
      {editMode ?
        <input
          onBlur={(e) => setEditMode(false)}
          type="text" value={val}
          onChange={(e) => setVal(e.target.value)} /> :
        <div
          onDoubleClick={e => setEditMode(true)}>
          {val}
        </div>}
    </div>
  )
}

export default Text