import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { addNote } from '../Redux/action';
import '../App.css'

export default function NotesForm() {

  let [title, setTitle] = useState('');
  let [content, setContent] = useState('')

  const dispatch = useDispatch();

  const navigate = useNavigate();

  function handleSubmission(e){
    e.preventDefault();
    dispatch(addNote(title, content))
    setTitle('')
    setContent('')
    navigate('/allNotes')
  }

  return (
    <div className='main'>
    <div className='formContainer'>
        <h3>React Notes App</h3>
        <form onSubmit={handleSubmission}>
           
            <label for='maintitle'>
            <h4 className='heading'>Title</h4>
            <input type='text' id='maintitle' name='title' value={title} placeholder='Enter title' onChange = {(e)=> setTitle(e.target.value)} required/> </label><br/>
            
            <label for='maincontent'>
            <h4 className='heading'>content</h4>
            <input type='text' id='maincontent' name='content' value={content} placeholder='Enter content' onChange = {(e)=> setContent(e.target.value)} required/></label> <br/>
            <br/>
            <button class="button-29" role="button">Add note</button>
           
        </form>
    </div>
    </div>
  )
}
