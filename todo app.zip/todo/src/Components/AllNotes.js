import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { removeNote } from '../Redux/action';
import { useNavigate } from 'react-router-dom';
import Text from './Textupdate';
import '../App.css'


export default function AllNotes() {

  
  const notes = useSelector((state) => state.notes)
  console.log(notes)
  const dispatch = useDispatch();
  const navigate = useNavigate()

  return (
    <>
      <button className="button-29" role="button" onClick={() => navigate('/')}>Home</button>
      <div className='d-flex'>
        {
          notes.map((note, index) => {
             
            return (
              <>
              <div className='maincont'>
                <div className="card" style={{ width: "18rem", margin: '2rem' }}>
                  <div className="card-body">
                    <h5 className="card-title"><Text className="card-title" value={note.title} /></h5>
                    <p className="card-text"><Text className="card-title" value={note.content} /></p>
                    <a href="#" className="btn btn-danger" onClick={() => dispatch(removeNote(index))}>Delete</a>
                    <button className="btn btn-primary">Update</button> <br></br>
                    <abbr>Double click on text to Update.</abbr>
                  </div>
                </div>
                </div>
              </>

            )
          })
        }

      </div>
    </>

  )
}
